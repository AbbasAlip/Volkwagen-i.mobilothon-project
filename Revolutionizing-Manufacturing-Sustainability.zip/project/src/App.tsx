import React, { useState, useEffect } from 'react';
import { Thermometer, Droplets, Zap, Factory } from 'lucide-react';
import DashboardCard from './components/DashboardCard';
import Chart from './components/Chart';
import RecommendationPanel from './components/RecommendationPanel';

// Simulated data - replace with actual API calls
const generateMockData = () => ({
  temperature: Math.round((20 + Math.random() * 10) * 10) / 10,
  humidity: Math.round((50 + Math.random() * 20) * 10) / 10,
  energy: Math.round((400 + Math.random() * 100) * 10) / 10,
  emissions: Math.round((200 + Math.random() * 50) * 10) / 10,
});

const mockRecommendations = [
  {
    parameter: 'Machine Speed',
    currentValue: 1200,
    suggestedValue: 1000,
    unit: 'rpm',
    impact: 'Energy -15%'
  },
  {
    parameter: 'Temperature',
    currentValue: 25,
    suggestedValue: 23,
    unit: '°C',
    impact: 'Efficiency +8%'
  }
];

function App() {
  const [currentData, setCurrentData] = useState(generateMockData());
  const [historicalData, setHistoricalData] = useState({
    temperature: Array(12).fill(0).map(() => Math.round((20 + Math.random() * 10) * 10) / 10),
    labels: Array(12).fill(0).map((_, i) => `${12 - i}m ago`),
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const newData = generateMockData();
      setCurrentData(newData);
      setHistoricalData(prev => ({
        temperature: [...prev.temperature.slice(1), newData.temperature],
        labels: prev.labels,
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Factory Monitoring Dashboard</h1>
            <p className="mt-2 text-gray-600">Real-time sensor data and optimization suggestions</p>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full">System Online</div>
            <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full">Last Update: Just now</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Temperature"
            value={currentData.temperature}
            unit="°C"
            icon={<Thermometer className="w-6 h-6" />}
            status={currentData.temperature > 28 ? 'critical' : currentData.temperature > 25 ? 'warning' : 'good'}
          />
          <DashboardCard
            title="Humidity"
            value={currentData.humidity}
            unit="%"
            icon={<Droplets className="w-6 h-6" />}
            status={currentData.humidity > 65 ? 'critical' : currentData.humidity > 60 ? 'warning' : 'good'}
          />
          <DashboardCard
            title="Energy Usage"
            value={currentData.energy}
            unit="kWh"
            icon={<Zap className="w-6 h-6" />}
            status={currentData.energy > 450 ? 'critical' : currentData.energy > 420 ? 'warning' : 'good'}
          />
          <DashboardCard
            title="Carbon Emissions"
            value={currentData.emissions}
            unit="kg CO₂"
            icon={<Factory className="w-6 h-6" />}
            status={currentData.emissions > 230 ? 'critical' : currentData.emissions > 220 ? 'warning' : 'good'}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Chart
              data={historicalData.temperature}
              labels={historicalData.labels}
              label="Temperature"
              color="#3b82f6"
            />
          </div>
          <div>
            <RecommendationPanel recommendations={mockRecommendations} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;