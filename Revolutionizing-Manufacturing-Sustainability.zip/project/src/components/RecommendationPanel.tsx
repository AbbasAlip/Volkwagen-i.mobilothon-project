import React from 'react';
import { AlertCircle, ArrowRight } from 'lucide-react';

interface Recommendation {
  parameter: string;
  currentValue: number;
  suggestedValue: number;
  unit: string;
  impact: string;
}

interface RecommendationPanelProps {
  recommendations: Recommendation[];
}

export default function RecommendationPanel({ recommendations }: RecommendationPanelProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <AlertCircle className="w-6 h-6 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-800">Optimization Recommendations</h3>
      </div>
      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-700 font-medium">{rec.parameter}</span>
              <span className="text-sm text-gray-500">Expected Impact: {rec.impact}</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-gray-600">{rec.currentValue}{rec.unit}</span>
              <ArrowRight className="w-4 h-4 text-blue-500" />
              <span className="text-blue-600 font-semibold">{rec.suggestedValue}{rec.unit}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}