import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon: React.ReactNode;
  status: 'good' | 'warning' | 'critical';
}

const statusColors = {
  good: 'bg-green-100 text-green-800',
  warning: 'bg-yellow-100 text-yellow-800',
  critical: 'bg-red-100 text-red-800'
};

export default function DashboardCard({ title, value, unit, icon, status }: DashboardCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${statusColors[status]}`}>
            {icon}
          </div>
          <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        </div>
      </div>
      <div className="flex items-baseline mt-4">
        <div className="text-3xl font-bold text-gray-900">{value}</div>
        {unit && <div className="ml-2 text-gray-500">{unit}</div>}
      </div>
    </div>
  );
}